﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace WindowsService1
{
    [RunInstaller(true)]
    public partial class Service1 : ServiceBase
    {
        public Thread worker = null;

        string pathf = "C:\\Folder1";
        string pathf2 = "C:\\Folder2";

        FileSystemWatcher watcher,watcher2;
        public Service1()
        {
            InitializeComponent();

            

            
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                
                watcher = new FileSystemWatcher(pathf)
                {
                    EnableRaisingEvents = true,
                    IncludeSubdirectories = true
                };


                watcher.Changed += DirectoryChanged;
                watcher.Created += DirectoryChanged;
                watcher.Deleted += DirectoryChanged;
                watcher.Renamed += DirectoryChanged;

                
                watcher2 = new FileSystemWatcher(pathf2)
                {
                    EnableRaisingEvents = true,
                    IncludeSubdirectories = true
                };


                watcher2.Changed += DirectoryChanged2;
                watcher2.Created += DirectoryChanged2;
                watcher2.Deleted += DirectoryChanged2;
                watcher2.Renamed += DirectoryChanged2;

            }
            catch (Exception) { throw; }
        }

        private void DirectoryChanged2(object sender, FileSystemEventArgs e)
        {
            try
            {
                if (!EventLog.SourceExists("mytraxse"))
                    System.Diagnostics.EventLog.CreateEventSource("mytraxse", "mytraxse");
                EventLog log = new EventLog("mytraxse");
                log.Source = "mytraxse";
                var msg = $"{e.ChangeType} - {e.FullPath} {System.Environment.NewLine}";
                var serviceLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                File.AppendAllText($"{serviceLocation}\\log.txt", msg);
                log.WriteEntry(msg, EventLogEntryType.Information);
            }
            catch (Exception) { }
        }

        private void DirectoryChanged(object sender, FileSystemEventArgs e)
        {
            try
            {

                string dest = Path.Combine(@"C:\\Folder2", e.Name);
                if (File.Exists(dest))
                {
                    File.Delete(e.FullPath);
                }
                else
                {
                    File.Move(e.FullPath, dest);
                }

                if (!EventLog.SourceExists("mytraxse"))
                    System.Diagnostics.EventLog.CreateEventSource("mytraxse", "mytraxse");
                EventLog log = new EventLog("mytraxse");
                log.Source = "mytraxse";
                var msg = $"{e.ChangeType} - {e.FullPath} {System.Environment.NewLine}";
                var serviceLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                File.AppendAllText($"{serviceLocation}\\log.txt", msg);
                log.WriteEntry(msg, EventLogEntryType.Information);

                
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }


        protected override void OnStop()
        {

        }
    }
}
