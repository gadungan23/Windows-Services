﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace WindowsService1
{
    [RunInstaller(true)]
    public partial class Service1 : ServiceBase
    {
        public Thread worker = null;
        FileSystemWatcher watcher;
        public Service1()
        {
            InitializeComponent();

            

            
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                string pathf = "C:\\Folder1";
                watcher = new FileSystemWatcher(pathf)
                {
                    EnableRaisingEvents = true,
                    IncludeSubdirectories = true
                };


                watcher.Changed += DirectoryChanged;
                watcher.Created += DirectoryChanged;
                watcher.Deleted += DirectoryChanged;
                watcher.Renamed += DirectoryChanged;

            }
            catch (Exception) { throw; }
        }

        private void DirectoryChanged(object sender, FileSystemEventArgs e)
        {
            try
            {
                if (!EventLog.SourceExists("mytraxse"))
                    System.Diagnostics.EventLog.CreateEventSource("mytraxse", "mytraxse");
                EventLog log = new EventLog("mytraxse");
                log.Source = "mytraxse";
                var msg = $"{e.ChangeType} - {e.FullPath} {System.Environment.NewLine}";
                var serviceLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
                File.AppendAllText($"{serviceLocation}\\log.txt", msg);
                log.WriteEntry(msg, EventLogEntryType.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }


        protected override void OnStop()
        {

        }
    }
}
